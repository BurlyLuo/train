[root@dev1 webhook]# git clone https://github.com.cnpmjs.org/morvencao/kube-mutating-webhook-tutorial.git
Cloning into 'kube-mutating-webhook-tutorial'...
remote: Enumerating objects: 186, done.
remote: Counting objects: 100% (16/16), done.
remote: Compressing objects: 100% (14/14), done.
remote: Total 186 (delta 4), reused 6 (delta 2), pack-reused 170
Receiving objects: 100% (186/186), 219.19 KiB | 0 bytes/s, done.
Resolving deltas: 100% (88/88), done.
[root@dev1 webhook]# ll
total 4
drwxr-xr-x 6 root root 4096 Dec 27 21:07 kube-mutating-webhook-tutorial
[root@dev1 webhook]# cd kube-mutating-webhook-tutorial/
[root@dev1 kube-mutating-webhook-tutorial]# ll
total 276
drwxr-xr-x 2 root root     24 Dec 27 21:07 build
drwxr-xr-x 2 root root     39 Dec 27 21:07 cmd
drwxr-xr-x 2 root root   4096 Dec 27 21:07 deploy
-rw-r--r-- 1 root root   6497 Dec 27 21:07 golangci.yml
-rw-r--r-- 1 root root   1930 Dec 27 21:07 go.mod
-rw-r--r-- 1 root root   6841 Dec 27 21:07 go.sum
-rw-r--r-- 1 root root  11357 Dec 27 21:07 LICENSE
-rw-r--r-- 1 root root   3219 Dec 27 21:07 Makefile
-rw-r--r-- 1 root root  35719 Dec 27 21:07 medium-article.md
-rw-r--r-- 1 root root 190940 Dec 27 21:07 mutating-admission-webhook.jpg
-rw-r--r-- 1 root root   3145 Dec 27 21:07 mutating-admission-webhook.xml
-rw-r--r-- 1 root root   4657 Dec 27 21:07 README.md
[root@dev1 kube-mutating-webhook-tutorial]# pwd 
/root/adv/webhook/kube-mutating-webhook-tutorial
[root@dev1 kube-mutating-webhook-tutorial]# 




#### verify the environment:
[root@dev1 deploy]# kubectl api-versions | grep admissionregistration.k8s.io
admissionregistration.k8s.io/v1
admissionregistration.k8s.io/v1beta1
[root@dev1 deploy]# 

1.create ns webhook：
kubectl create ns webhook

2.Create a signed cert/key pair and store it in a Kubernetes secret that will be consumed by sidecar injector deployment under webhook ns:
./deploy/webhook-create-signed-cert.sh \
    --service sidecar-injector-webhook-svc \
    --secret sidecar-injector-webhook-certs \
    --namespace webhook

3.Patch the MutatingWebhookConfiguration by set caBundle with correct value from Kubernetes cluster:
cat deploy/mutatingwebhook.yaml | \
    deploy/webhook-patch-ca-bundle.sh > \
    deploy/mutatingwebhook-ca-bundle.yaml

4.Deploy resources:
kubectl create -f deploy/nginxconfigmap.yaml
kubectl create -f deploy/configmap.yaml
kubectl create -f deploy/deployment.yaml
kubectl create -f deploy/service.yaml
kubectl create -f deploy/mutatingwebhook-ca-bundle.yaml

5.view sidecar-injector-webhook-deployment deploy:
kubectl -nwebhook get pods -o wide 

6. label ns webhook with sidecar-injector=enabled
kubectl label namespace webhook sidecar-injection=enabled
kubectl get namespace -L sidecar-injection

7.create the test pod alpine:
kubectl run alpine --image=alpine --restart=Never -n webhook --overrides='{"apiVersion":"v1","metadata":{"annotations":{"sidecar-injector-webhook.morven.me/inject":"yes"}}}' --command -- sleep infinity

8.verify the test pod alpine:
kubectl -nwebhook get pods alpine -o wide

 